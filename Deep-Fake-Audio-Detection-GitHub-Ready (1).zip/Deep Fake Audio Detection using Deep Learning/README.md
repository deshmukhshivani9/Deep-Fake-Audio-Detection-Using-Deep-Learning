# Deep Fake Audio Detection Using Deep Learning

A Django-based deep learning application for detecting whether an uploaded audio sample is **Fake** or **Original**.

## Technologies
- Python
- Django
- TensorFlow / Keras
- CNN
- LSTM
- MFCC
- Librosa
- NumPy
- Scikit-learn

## Project Structure
- `DeepFake/` - Django project configuration
- `DeepFakeApp/` - application, views, templates and static files
- `model/` - trained CNN-LSTM model and preprocessed feature files
- `manage.py` - Django entry point
- `test.py` - model training/testing script
- `requirements.txt` - project dependencies
- `DatasetLink.txt` - dataset reference

## Dataset
The original audio dataset is not included in this repository because it is large. See `DatasetLink.txt` for the dataset reference.

## Run
1. Install the required Python dependencies.
2. Open a terminal in the project folder.
3. Run:
   `python manage.py runserver`
4. Open the local Django server in a browser.
5. Log in and upload an audio file to obtain the prediction.

## Note
The trained model is included in the `model/` directory so the application can use the saved CNN-LSTM weights without uploading the full training dataset.
